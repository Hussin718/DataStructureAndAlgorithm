package com.example.Structure.structurebase;

public class Heapq {
    private Node[] heap;
    private int length;
    private int capacity;

    public Heapq(int capacity) {
        this.capacity = capacity;
        this.heap = new Node[capacity];
        this.length = 0;
    }

    public void push(Node newNode) {
        if (length == capacity) {
            System.out.println("Heap is full");
            return; // توقف هنا لمنع الخطأ
        }
        // 1. أضف العنصر في نهاية المصفوفة
        heap[length] = newNode;
        // 2. ارفعه للأعلى لمكانه الصحيح (Sift Up)
        heapifyUp(length);
        length++;
    }

    private void heapifyUp(int index) {
        int parent = (index - 1) / 2;
        // طالما لم نصل للجذر، وقيمة العنصر الحالي أصغر من والده (Min-Heap)
        if (index > 0 && heap[index].getEvaluation() < heap[parent].getEvaluation()) {
            swap(index, parent);
            heapifyUp(parent);
        }
    }

    public Node pop() {
        if (length == 0) {
            System.out.println("Heap is empty");
            return null;
        }
        Node root = heap[0];
        // ضع آخر عنصر في مكان الجذر
        heap[0] = heap[length - 1];
        length--;
        // نزله لمكانه الصحيح
        heapifyDown(0);
        return root;
    }

    public void heapifyDown(int index) {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < length && heap[left].getEvaluation() < heap[smallest].getEvaluation()) {
            smallest = left;
        }
        if (right < length && heap[right].getEvaluation() < heap[smallest].getEvaluation()) {
            smallest = right;
        }

        if (smallest != index) {
            swap(index, smallest);
            heapifyDown(smallest);
        }
    }

    private void swap(int i, int j) {
        Node temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    public boolean isEmpty() {
        return length == 0;
}
}
